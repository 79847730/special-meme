﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

       /***********************************接收数据处理***********************/
        List<byte> byteBuffer = new List<byte>();       //接收字节缓存区

        private string BytesToText(byte[] bytes, string encoding)       //字节流转文本
        {
            List<byte> byteDecode = new List<byte>();   //需要转码的缓存区
            byteBuffer.AddRange(bytes);     //接收字节流到接收字节缓存区
            if (encoding == "GBK")
            {
                int count = byteBuffer.Count;
                for (int i = 0; i < count; i++)
                {
                    if (byteBuffer.Count == 0)
                    {
                        break;
                    }
                    if (byteBuffer[0] < 0x80)       //1字节字符
                    {
                        byteDecode.Add(byteBuffer[0]);
                        byteBuffer.RemoveAt(0);
                    }
                    else       //2字节字符
                    {
                        if (byteBuffer.Count >= 2)
                        {
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                        }
                    }
                }
            }
            else if (encoding == "UTF-8")
            {
                int count = byteBuffer.Count;
                for (int i = 0; i < count; i++)
                {
                    if (byteBuffer.Count == 0)
                    {
                        break;
                    }
                    if ((byteBuffer[0] & 0x80) == 0x00)     //1字节字符
                    {
                        byteDecode.Add(byteBuffer[0]);
                        byteBuffer.RemoveAt(0);
                    }
                    else if ((byteBuffer[0] & 0xE0) == 0xC0)     //2字节字符
                    {
                        if (byteBuffer.Count >= 2)
                        {
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                        }
                    }
                    else if ((byteBuffer[0] & 0xF0) == 0xE0)     //3字节字符
                    {
                        if (byteBuffer.Count >= 3)
                        {
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                        }
                    }
                    else if ((byteBuffer[0] & 0xF8) == 0xF0)     //4字节字符
                    {
                        if (byteBuffer.Count >= 4)
                        {
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                            byteDecode.Add(byteBuffer[0]);
                            byteBuffer.RemoveAt(0);
                        }
                    }
                    else        //其他
                    {
                        byteDecode.Add(byteBuffer[0]);
                        byteBuffer.RemoveAt(0);
                    }
                }
            }
            return Encoding.GetEncoding(encoding).GetString(byteDecode.ToArray());
        }

        public TransmitData transmitData;
        

        private byte[] HexToBytes(string str)       //HEX转字节流
        {
            string str1 = Regex.Replace(str, "[^A-F^a-f^0-9]", "");     //清除非法字符

            double i = str1.Length;     //将字符两两拆分
            int len = 2;
            string[] strList = new string[int.Parse(Math.Ceiling(i / len).ToString())];
            for (int j = 0; j < strList.Length; j++)
            {
                len = len <= str1.Length ? len : str1.Length;
                strList[j] = str1.Substring(0, len);
                str1 = str1.Substring(len, str1.Length - len);
            }

            int count = strList.Length;     //将拆分后的字符依次转换为字节
            byte[] bytes = new byte[count];
            for (int j = 0; j < count; j++)
            {
                bytes[j] = byte.Parse(strList[j], NumberStyles.HexNumber);
            }

            return bytes;
        }
        private byte[] TextToBytes(string str, string encoding)     //文本转字节流
        {
            return Encoding.GetEncoding(encoding).GetBytes(str);
        }

        private string BytesToHex(byte[] bytes)     //字节流转HEX
        {
            string hex = "";
            foreach (byte b in bytes)
            {
                hex += b.ToString("X2") + " ";
            }
            return hex;
        }

        /*****************************串口接收*************************************/
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                int count = serialPort1.BytesToRead;
                byte[] dataReceive = new byte[count];
                serialPort1.Read(dataReceive, 0, count);     //串口接收
           
                this.BeginInvoke((EventHandler)(delegate
                {
                    if (comboBox6.Text == "16进制模式")
                    {
                        textBox1.AppendText(BytesToHex(dataReceive));  //字节流转HEX
                    }
                    else if (comboBox6.Text == "文本模式")
                    {
                       textBox1.AppendText(BytesToText(dataReceive, comboBox7.Text));       //字节流转文本
                       transmitData?.Invoke(dataReceive);
                    }
                }));     
                
            }
        }

        /****************************串口热插拔检测************************************/
        string serialPortName;
       
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0219)
            {//设备改变
                if (m.WParam.ToInt32() == 0x8004)
                {//usb串口拔出
                    if (button1.Text == "关闭串口")
                    {//用户打开过串口

                        if (!serialPort1.IsOpen)
                        {//用户打开的串口被关闭:说明热插拔是用户打开的串口
    
                            button1.Text = "打开串口";                       
                            comboBox1.Enabled = true;
                            comboBox2.Enabled = true;
                            comboBox3.Enabled = true;
                            comboBox4.Enabled = true;
                            comboBox5.Enabled = true;
                            serialPort1.Dispose();//释放掉原先的串口资源
                            string[] ports_= SerialPort.GetPortNames();//重新获取串口
                            comboBox1.Items.Clear();
                            comboBox1.Items.AddRange(ports_);
                      //   comboBox1.SelectedIndex = comboBox1.Items.Count > 0 ? 0 : -1;//显示获取的第一个串口号
                        }
                    }
                    else
                    {//用户没有打开过串口
                        string[] ports1 = SerialPort.GetPortNames();//重新获取串口
                        comboBox1.Items.Clear();
                        comboBox1.Items.AddRange(ports1);
                        comboBox1.SelectedIndex = comboBox1.Items.Count > 0 ? 0 : -1;//显示获取的第一个串口号
                    }
                }
                else if (m.WParam.ToInt32() == 0x8000)
                {//usb串口连接上
                    string[] ports = SerialPort.GetPortNames();//重新获取串口
                    comboBox1.Items.Clear();
                    comboBox1.Items.AddRange(ports);
                    if (button1.Text == "关闭串口")
                    {//用户打开过一个串口
                        comboBox1.Text = serialPortName;//显示用户打开的那个串口号
                      //  MessageBox.Show(serialPortName);//对话框显示打开失败
                    }
                    else
                    {
                    comboBox1.SelectedIndex = comboBox1.Items.Count > 0 ? 0 : -1;//显示获取的第一个串口号
                    }
                }
            }
            base.WndProc(ref m);
        }
        private void comboBox1_DropDown(object sender, EventArgs e)
        {
           string currentName = comboBox1.Text;
           string[] names = SerialPort.GetPortNames();       //搜索可用串口号并添加到下拉列表
           comboBox1.Items.Clear();
           comboBox1.Items.AddRange(names);
           comboBox1.SelectedIndex = comboBox1.Items.Count > 0 ? 0 : -1;//显示获取的第一个串口号
        }
        /******************************窗口加载事件  初始化*********************************/
        public Form1()
        {
            InitializeComponent();
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;//设置该属性 为false
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
           
           string[] ports = System.IO.Ports.SerialPort.GetPortNames();//获取电脑上可用串口号
           comboBox1.Items.AddRange(ports);//给comboBox1添加数据
           comboBox1.SelectedIndex = comboBox1.Items.Count > 0 ? 0 : -1;//如果里面有数据,显示第0个
           comboBox2.Text = "9600";/*默认波特率:115200*/
           comboBox3.Text = "1";/*默认停止位:1*/
           comboBox4.Text = "8";/*默认数据位:8*/
           comboBox5.Text = "无";/*默认奇偶校验位:无*/
           comboBox6.Text = "文本模式";
           comboBox7.Text = "UTF-8";
           comboBox8.Text = "文本模式";
           comboBox9.Text = "UTF-8";
           checkBox1.Checked = true;

           
        }

        /*********************************打开串口函数*********************************/
        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                if (button1.Text == "打开串口")
                {//如果按钮显示的是打开串口
                    try
                    {//防止意外错误
                        serialPort1.PortName = comboBox1.Text;//获取comboBox1要打开的串口号
                        serialPortName = comboBox1.Text;
                        serialPort1.BaudRate = int.Parse(comboBox2.Text);//获取comboBox2选择的波特率
                        serialPort1.DataBits = int.Parse(comboBox4.Text);//设置数据位
                        /*设置停止位*/
                        if (comboBox3.Text == "1") { serialPort1.StopBits = StopBits.One; }
                        else if (comboBox3.Text == "1.5") { serialPort1.StopBits = StopBits.OnePointFive; }
                        else if (comboBox3.Text == "2") { serialPort1.StopBits = StopBits.Two; }
                        /*设置奇偶校验*/
                        if (comboBox5.Text == "无") { serialPort1.Parity = Parity.None; }
                        else if (comboBox5.Text == "奇校验") { serialPort1.Parity = Parity.Odd; }
                        else if (comboBox5.Text == "偶校验") { serialPort1.Parity = Parity.Even; }
                        serialPort1.Open();//打开串口
                        button1.Text = "关闭串口";//按钮显示关闭串口
                        comboBox1.Enabled = false;
                        comboBox2.Enabled = false;
                        comboBox3.Enabled = false;
                        comboBox4.Enabled = false;
                        comboBox5.Enabled = false;
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("打开失败" + err.ToString(), "提示!");//对话框显示打开失败
                    }
                }
                else
                {//要关闭串口
                    try
                    {//防止意外错误
                        comboBox1.Enabled = true;
                        comboBox2.Enabled = true;
                        comboBox3.Enabled = true;
                        comboBox4.Enabled = true;
                        comboBox5.Enabled = true;
                        serialPort1.Close();//关闭串口
                    }
                    catch (Exception) { }
                    button1.Text = "打开串口";//按钮显示打开
                }
            }
            else
            {
                if (button1.Text == "打开串口")
                { 
                 MessageBox.Show("串口端口号为空");
                }   
            }
        }

        /************************************发送函数********************************/
        private void button5_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                if (comboBox8.Text == "16进制模式")
                {
                    byte[] dataSend = HexToBytes(textBox2.Text);      //HEX转字节流
                    int count = dataSend.Length;
                    serialPort1.Write(dataSend, 0, count);       //串口发送
                }
                else if (comboBox8.Text == "文本模式")
                {
                    if (checkBox1.Checked == true )
                    {
                        byte[] dataSend = TextToBytes("@" + textBox2.Text + "\r\n", comboBox9.Text);      //文本转字节流
                        int count = dataSend.Length;
                        serialPort1.Write(dataSend, 0, count);       //串口发送
                    }
                    else
                    {
                        byte[] dataSend = TextToBytes(textBox2.Text, comboBox9.Text);      //文本转字节流
                        int count = dataSend.Length;
                        serialPort1.Write(dataSend, 0, count);       //串口发送
                    }
                }
            }
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)     //发送模式选择事件
        {
            if (comboBox8.Text == "16进制模式")
            {
                comboBox9.Enabled = false;
            }
            else if (comboBox8.Text == "文本模式")
            {
                comboBox9.Enabled = true;
            }
        }

        /**********************************接收模式选择***************************************/
        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)  //接收模式选择事件
        {
            if (comboBox6.Text == "16进制模式")
            {
                comboBox7.Enabled = false;
            }
            else if (comboBox6.Text == "文本模式")
            {
                comboBox7.Enabled = true;
            }
            byteBuffer.Clear();
        }
        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)//接收编码选择事件
        {
            byteBuffer.Clear();
        }    
        /*************************清除按钮**********************/
        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Clear();
        }
        private void button4_Click_1(object sender, EventArgs e)
        {
            textBox2.Clear();
        }

      
        Form2 form2;
        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {   

                if (form2 == null) //如果子窗体为空则创造实例 并显示
                {
                    form2 = new Form2();
                    form2.StartPosition = FormStartPosition.CenterScreen;//子窗体居中显示
                    form2.Show();
                    
                }
                else
                {
                    if (form2.IsDisposed) //若子窗体关闭 则打开新子窗体 并显示
                    {
                        form2 = new Form2();
                        form2.StartPosition = FormStartPosition.CenterScreen;//子窗体居中显示
                        form2.Show();
                    }
                    else
                    {
                        form2.Activate(); //使子窗体获得焦点
                    }
                }
                transmitData = form2.ReciveDate;
                form2.useform1Send = sendBytes;
            }
            else
            {
                MessageBox.Show("你怎么能随便使用后备隐藏能源呢?");
            }
        }

        private void sendBytes(string data)
        {
            if (serialPort1.IsOpen)
            {
                if (comboBox8.Text == "16进制模式")
                {
                    byte[] dataSend = HexToBytes(data);      //HEX转字节流
                    int count = dataSend.Length;
                    serialPort1.Write(dataSend, 0, count);       //串口发送
                }
                else if (comboBox8.Text == "文本模式")
                {
                    if (checkBox1.Checked == true)
                    {
                        byte[] dataSend = TextToBytes("@" + data + "\r\n", comboBox9.Text);      //文本转字节流
                        int count = dataSend.Length;
                        serialPort1.Write(dataSend, 0, count);       //串口发送
                    }
                    else
                    {
                        byte[] dataSend = TextToBytes(data, comboBox9.Text);      //文本转字节流
                        int count = dataSend.Length;
                        serialPort1.Write(dataSend, 0, count);       //串口发送
                    }
                }
            }
        }

       
        private void button6_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog
            {
                //设置保存文件对话框的标题
                Title = "保存的文件路径",
                //初始化保存目录，默认exe文件目录
                InitialDirectory = Application.StartupPath,
                Filter = "文本文件 (*.txt)|*.txt|所有文件 (*.*)|*.*"
            };
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                //获得保存文件的路径
                string filePath = sfd.FileName;  //保存
                File.WriteAllText(filePath, string.Empty);//清除原本内容
                using (FileStream fsWrite = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    byte[] buffer = Encoding.Default.GetBytes(textBox1.Text.ToString().Trim());
                    fsWrite.Write(buffer, 0, buffer.Length);
                }
            }
        }
    }
}
