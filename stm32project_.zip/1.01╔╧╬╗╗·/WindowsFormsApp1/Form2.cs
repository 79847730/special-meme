﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.AxHost;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;



namespace WindowsFormsApp1
{


    public partial class Form2 : Form
    {

        public TransmitData_us useform1Send;

        int x = 0;
        int y = 0;
        int z = 0;
        int g = 0;
        int state = 0;
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            checkBox1.Checked = false;
            checkBox2.Checked = true ;
            button12.Text = "失能";
            comboBox1.Text = "逆向运动学";
            label7.Visible = false;
        }

        string str;
      
        public void ReciveDate(byte[] tempdate)
        {
            str = Encoding.GetEncoding("UTF-8").GetString(tempdate);
            if (str != null)
            {
                Match match = Regex.Match(str, @"\((.*?)\)");
                if (match.Success)
                {
                    string content = match.Groups[1].Value; // 获取括号内的内容
                    string[] array;
                    array = content.Split(',');
                    x = int.Parse(array[0]);
                    y = int.Parse(array[1]);
                    z = int.Parse(array[2]);
                    g = int.Parse(array[3]);
                    state = int.Parse(array[4]);      
                    label1.Text = x.ToString();
                    label2.Text = y.ToString();
                    label3.Text = z.ToString();
                    if (state==0)
                    {
                        checkBox3.Checked = false;
                    }
                    else  if (state == 1)
                    {
                        checkBox3.Checked = true;
                    }
              
                }
               
            }
            if (checkBox1.Checked == true)
            { 
                textBox1.Text = str;

            }
        }
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            checkBox1.Checked = false;
        }

        /***************************x 加*******************************************/
         int  x_variation;
        int y_variation;
        int z_variation;
        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
                x = x_variation;
                label1.Text = x.ToString();
                timer2.Interval = 20;//timer2_Tick那段代码每2秒执行一次，初始执行，在2秒之后才正式开始
                timer2.Enabled = true;//开启timer2
               }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("RunX1");
            }
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            { 
            //无论用户在2s内还是在2s之后就松开鼠标，就马上停止timer3,timer1的代码执行
            //如果用户在2s内松开鼠标,time1_Tick根本1次都不会执行
            timer2.Enabled = false;
            timer1.Enabled = false;
            useform1Send.Invoke("X" + "(" + x_variation + "," + y + "," + z + ")" + "M");
            }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("StopX");
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer1.Interval = 20;//timer1的代码每0.05s执行一次
            timer1.Enabled = true;//开始timer1
            //关闭time2，timer2_Tick这段代码就不要每2秒执行一次了，执行1次就好，这句话就完成timer2与timer1的线程同步
            timer2.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            x_variation++;
            label1.Text = x_variation.ToString();
        }
        /****************************x 减**********************************************/
        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
            x_variation = x;
            label1.Text = x.ToString();
            timer4.Interval = 20;//timer2_Tick那段代码每2秒执行一次，初始执行，在2秒之后才正式开始
            timer4.Enabled = true;//开启timer2
            }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("RunX0");
            }

        }

        private void button3_MouseUp(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            { 
            timer4.Enabled = false;
            timer3.Enabled = false;
            useform1Send.Invoke("X" + "(" + x_variation + "," + y + "," + z + ")" + "M");
            }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("StopX");
            }

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            x_variation--;
            label1.Text = x_variation.ToString();
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            timer3.Interval = 20;//timer1的代码每0.05s执行一次
            timer3.Enabled = true;//开始timer1
            timer4.Enabled = false;
        }
        /**************************发送按钮***************************************/
        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true) 
            {
              useform1Send.Invoke("X"+textBox2.Text+"M");
            }
            else 
                useform1Send.Invoke(textBox2.Text);
        }
        /***********************************y的加***********************************************/
        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
                y_variation = y;
                label2.Text = y.ToString();
                timer6.Interval = 20;//timer2_Tick那段代码每2秒执行一次，初始执行，在2秒之后才正式开始
                timer6.Enabled = true;//开启timer2
            }
            else if (comboBox1.Text == "正向运动学")
            {
             useform1Send.Invoke("RunY1");
            }
        }

        private void button4_MouseUp(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
                timer6.Enabled = false;
                timer5.Enabled = false;
                useform1Send.Invoke("X" + "(" + x + "," + y_variation + "," + z + ")" + "M");
            }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("StopY");
            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            y_variation++;
            label2.Text = y_variation.ToString();
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            timer5.Interval = 20;//timer1的代码每0.05s执行一次
            timer5.Enabled = true;//开始timer1
            //关闭time2，timer2_Tick这段代码就不要每2秒执行一次了，执行1次就好，这句话就完成timer2与timer1的线程同步
            timer6.Enabled = false;
        }
        /***************************y减***********************************/
        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {           
            y_variation = y;
            label2.Text = y.ToString();
            timer8.Interval = 20;//timer2_Tick那段代码每2秒执行一次，初始执行，在2秒之后才正式开始
            timer8.Enabled = true;//开启timer2
            }
            else if (comboBox1.Text == "正向运动学")
            {
            useform1Send.Invoke("RunY0");
            }

        }

        private void button5_MouseUp(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学") 
            {
            timer8.Enabled = false;
            timer7.Enabled = false;
            useform1Send.Invoke("X"+"(" + x + "," + y_variation + "," + z + ")"+ "M");           
            }
            else if (comboBox1.Text == "正向运动学")
            {
             useform1Send.Invoke("StopY");
            }

        }
        private void timer7_Tick_1(object sender, EventArgs e)
        {
            y_variation--;
            label2.Text = y_variation.ToString();
        }
        private void timer8_Tick_1(object sender, EventArgs e)
        {
            timer7.Interval = 20;//timer1的代码每0.05s执行一次
            timer7.Enabled = true;//开始timer1
            //关闭time2，timer2_Tick这段代码就不要每2秒执行一次了，执行1次就好，这句话就完成timer2与timer1的线程同步
            timer8.Enabled = false;
        }
        /*********************************************************/

        private void button6_MouseDown(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
            z_variation = z;
            label3.Text = z.ToString();
            timer10.Interval = 20;//timer2_Tick那段代码每2秒执行一次，初始执行，在2秒之后才正式开始
            timer10.Enabled = true;//开启timer2
            }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("RunZ0");
            }

        }

        private void button6_MouseUp(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
            timer10.Enabled = false;
            timer9.Enabled = false;
            useform1Send.Invoke("X" + "(" + x + "," + y + "," + z_variation + ")" + "M");
            }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("StopZ");
            }

        }

        private void timer9_Tick(object sender, EventArgs e)
        {
            z_variation++;
            label3.Text = z_variation.ToString();

        }

        private void timer10_Tick(object sender, EventArgs e)
        {
            timer9.Interval = 20;//timer1的代码每0.05s执行一次
            timer9.Enabled = true;//开始timer1
            //关闭time2，timer2_Tick这段代码就不要每2秒执行一次了，执行1次就好，这句话就完成timer2与timer1的线程同步
            timer10.Enabled = false;
        }
        /********************** Z减  ******************************/
        private void button7_MouseDown(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
            z_variation =z;
            label3.Text = z.ToString();
            timer12.Interval = 20;//timer2_Tick那段代码每2秒执行一次，初始执行，在2秒之后才正式开始
            timer12.Enabled = true;//开启timer2
            }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("RunZ1");
            }

        }

        private void button7_MouseUp(object sender, MouseEventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {           
            timer12.Enabled = false;
            timer11.Enabled = false;
            useform1Send.Invoke("X" + "(" + x + "," + y + "," + z_variation + ")"+"M");
            }
            else if (comboBox1.Text == "正向运动学")
            {
                useform1Send.Invoke("StopZ");
            }

        }
        private void timer11_Tick(object sender, EventArgs e)
        {
            z_variation--;
            label3.Text = z_variation.ToString();

        }

        private void timer12_Tick(object sender, EventArgs e)
        {
            timer11.Interval = 20;//timer1的代码每0.05s执行一次
            timer11.Enabled = true;//开始timer1
            timer12.Enabled = false;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (button9.Text == "复位")
            {//如果按钮显示的是打开串口
                useform1Send.Invoke("Reset");
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button10.Enabled = false;
                button11.Enabled = false;
                button12.Enabled = false;
                comboBox2.Enabled = false;
                comboBox1.Enabled = false;
                button9.Text = "复位中";
            }
           else
            {
                if (state!= 3)
                {
                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = true;
                    button4.Enabled = true;
                    button5.Enabled = true;
                    button6.Enabled = true;
                    button7.Enabled = true;
                    button10.Enabled = true;
                    button11.Enabled = true;
                    button12.Enabled = true;
                    comboBox2.Enabled = true;
                    comboBox1.Enabled = true;
                    button9.Text = "复位";//按钮显示关闭串口
                    button10.Text = "夹爪:关";//按钮显示关闭串口
                    label1.Text = x.ToString();
                    label2.Text = y.ToString();
                    label3.Text = z.ToString();
                }
            }
        }

        private void button33_Click(object sender, EventArgs e)
        {
            if (button10.Text == "夹爪:开")
            {//如果按钮显示的是打开串口
                g = 0;
                if (comboBox1.Text == "逆向运动学")
                {
                 useform1Send.Invoke("X" + "(" + x + "," + y + "," + z+","+g+ ")" + "M");
                }
                else if (comboBox1.Text == "正向运动学")
                {
                useform1Send.Invoke("Grip0");
                }
                button10.Text = "夹爪:关";//按钮显示关闭串口
            }
            else
            {
                g = 1;
                if (comboBox1.Text == "逆向运动学")
                {
                    useform1Send.Invoke("X" + "(" + x + "," + y + "," + z + "," + g + ")" + "M");
                }
                else if (comboBox1.Text == "正向运动学")
                {
                    useform1Send.Invoke("Grip1");
                }
                button10.Text = "夹爪:开";//按钮显示关闭串口
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label1.Text = x.ToString();
            label2.Text = y.ToString();
            label3.Text = z.ToString();

        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (button12.Text == "失能")
            {//如果按钮显示的是打开串口
                useform1Send.Invoke("Disable");
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button10.Enabled = false;
                button11.Enabled = false;
                button9.Enabled = false;
                button12.Text = "使能";
            }
            else
            {
                useform1Send.Invoke("Enable");
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                button6.Enabled = true;
                button7.Enabled = true;
                button10.Enabled = true;
                button11.Enabled = true;
                button9.Enabled = true;
                button12.Text = "失能";

            }
        }
        private void button13_Click(object sender, EventArgs e)
        {
            OpenFileDialog path = new OpenFileDialog
            {
                //设置打开文件对话框的标题
                Title = "打开的文件路径",
                // 指定打开文本文件（后缀名为txt）
                InitialDirectory = Application.StartupPath,
                Filter = "文本文件 (*.txt)|*.txt|所有文件 (*.*)|*.*"
            };
            if (path.ShowDialog() == DialogResult.OK)
            {
                string filePath = path.FileName;
                FileInfo fi = new FileInfo(filePath);
                // 读出文本文件的所以行
                string[] lines = File.ReadAllLines(path.FileName);

                if (fi.Length != 0)
                { 
                    textBox2.Clear();
                    foreach (string line in lines)
                    {
                        textBox2.AppendText(line);
                    }
                }
                else
                    MessageBox.Show("打开文件是空哒！");

            }
        }
        private void button14_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog
            {
                //设置保存文件对话框的标题
                Title = "保存的文件路径",
                //初始化保存目录，默认exe文件目录
                InitialDirectory = Application.StartupPath,
                Filter = "文本文件 (*.txt)|*.txt|所有文件 (*.*)|*.*"
            };
            if (sfd.ShowDialog() == DialogResult.OK)
                {
                //获得保存文件的路径
                string filePath = sfd.FileName;  //保存
                File.WriteAllText(filePath, string.Empty);//清除原本内容
                using (FileStream fsWrite = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write))
                 {
                    byte[] buffer = Encoding.Default.GetBytes(textBox2.Text.ToString().Trim());
                    fsWrite.Write(buffer, 0, buffer.Length);
                  }
                }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
                // useform1Send.Invoke("Mode0");
                label1.Enabled = true;
                label2.Enabled = true;
                label3.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                button6.Enabled = true;
                button7.Enabled = true;
                button9.Enabled = true;
                button10.Enabled = true;
                button11.Enabled = true;
                button2.Text = "X+";
                button3.Text = "X-";
                button4.Text = "Y+";
                button5.Text = "Y-";
                button6.Text = "Z+";
                button7.Text = "Z-";
            }
            else if (comboBox1.Text == "正向运动学")
            {

                label1.Enabled = false;
                label2.Enabled = false;
                label3.Enabled = false;
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                button6.Enabled = true;
                button7.Enabled = true;
                button9.Enabled = true;
                button10.Enabled = true;
                button11.Enabled = true;
                button2.Text = "←";
                button3.Text = "→";
                button4.Text = "↑";
                button5.Text = "↓";
                button6.Text = "↑";
                button7.Text = "↓";
            }
            if (comboBox1.Text == "MPU6050")
            {
                useform1Send.Invoke("Mode1");
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button9.Enabled = false;
                button10.Enabled = false;
                button11.Enabled = false;
            }
            else
            {
                if (str != null)
                { 
                useform1Send.Invoke("Mode0");
                }
            } 
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            useform1Send.Invoke("Speed"+ comboBox2.Text );
        }
        bool  key_X;
        bool  key_Y;
        bool  key_Z;
        bool key_G;
        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                if (key_X == true)
                {
                button2_MouseDown(null, null); key_X = false ;
                }
            }
            if (e.KeyCode == Keys.D)
            {
                if (key_X == true)
                {
                    button3_MouseDown(null, null); key_X = false;
                }
            }
            if (e.KeyCode == Keys.W)
            {
                if (key_Y == true)
                {
                    button4_MouseDown(null, null); key_Y = false;
                }
            }
            if (e.KeyCode == Keys.S)
            {
                if (key_Y == true)
                {
                    button5_MouseDown(null, null); key_Y = false;
                }
            }
            if (e.KeyCode == Keys.U)
            {
                if (key_Z == true)
                {
                    button6_MouseDown(null, null); key_Z = false;
                }
            }
            if (e.KeyCode == Keys.J)
            {
                if (key_Z == true)
                {
                    button7_MouseDown(null, null); key_Z = false;
                }
            }
            if (e.KeyCode == Keys.Space)
            {
                if (key_G == true)
                {
                    useform1Send.Invoke("Grip0"); key_G = false;
                }
            }
        }

        private void Form2_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.A:
                    button2_MouseUp(null, null); key_X = true;
                    break;
                case Keys.D:
                    button3_MouseUp(null, null); key_X = true;
                    break;
                case Keys.W:
                    button4_MouseUp(null, null); key_Y = true;
                    break;
                case Keys.S:
                    button5_MouseUp(null, null); key_Y = true;
                    break;
                case Keys.U:
                    button6_MouseUp(null, null); key_Z = true;
                    break;
                case Keys.J:
                    button7_MouseUp(null, null); key_Z = true;
                    break;
                case Keys.Space:
                    useform1Send.Invoke("Grip1"); key_G = true;
                    break;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                groupBox2.Focus();
                this.KeyPreview = true;
                label7.Visible = true;
            }
            if (checkBox4.Checked == false )
            {
                this.KeyPreview = false;
                label7.Visible = false;
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "逆向运动学")
            {
                MessageBox.Show("X+  X-  Y+  Y-  Z+  Z-   夹爪\n\r" +
                                "A   D   W   S   U   J   空格 ");
            }
            else if (comboBox1.Text == "正向运动学")
            {
                MessageBox.Show("←   →   ↑   ↓   ↑   ↓   夹爪\n\r" +
                             "A   D   W   S   U   J    空格");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            groupBox2.Focus();
        }
    }
}
