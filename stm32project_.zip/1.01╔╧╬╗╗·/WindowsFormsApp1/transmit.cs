﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{

    public delegate void TransmitData(byte[] data);
    public delegate void TransmitData_us(string data);
    public   class transmit : EventArgs 
    {
    }
}
