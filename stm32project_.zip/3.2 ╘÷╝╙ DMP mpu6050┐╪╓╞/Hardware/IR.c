#include "IR.h"
#include "DELAY.h"
#include "SERIAL.h"
/*********************外部变量************************/
uint32_t  gGUA_InfraredReceiver_Data = 0;  //一个接收红外原始数据的变量（32位）


/********************保存红外数据的变量*************/
uint8_t IR_RECEIVE[5];   // 每一项保存一个字节数据
int down16,up16;         // 分别保存低十六位和高十六位数据

uint8_t IR_State;		
uint8_t IR_DataFlag;    //单发标志
uint8_t IR_RepeatFlag;  //连发标志

/*********************内部函数************************/
static void GUA_Infrared_Receiver_IO_Init(void);
static uint16_t GUA_Infrared_Receiver_GetHighLevelTime(void);
static uint16_t GUA_Infrared_Receiver_GetLowLevelTime(void);

//******************************************************************************        
//name:             GUA_Infrared_Receiver_IO_Init        
//introduce:        红外接收的IO初始化  
static void GUA_Infrared_Receiver_IO_Init(void)
{   
    GPIO_InitTypeDef GPIO_InitStructure;	//IO结构体
//	//失能JTAG和SWD在PB3上的功能使用
//	GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);
//	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	//时钟使能
RCC_APB2PeriphClockCmd(GUA_INFRARED_RECEIVER_RCC | RCC_APB2Periph_AFIO, ENABLE);

	//红外接收IO配置
    GPIO_InitStructure.GPIO_Pin = GUA_INFRARED_RECEIVER_PIN;        
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 
    GPIO_Init(GUA_INFRARED_RECEIVER_PORT, &GPIO_InitStructure);  

    GPIO_EXTILineConfig(GUA_INFRARED_RECEIVER_PORTSOURCE, GUA_INFRARED_RECEIVER_PINSOURCE); 
}

//******************************************************************************            
//name:             GUA_Infrared_Receiver_Exti_Init
//introduce:        红外接收的IO中断初始化                             
//******************************************************************************
static void GUA_Infrared_Receiver_Exti_Init(void)
{   
	NVIC_InitTypeDef NVIC_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
	//中断配置
    EXTI_InitStructure.EXTI_Line = GUA_INFRARED_RECEIVER_EXTI_LINE;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger =  EXTI_Trigger_Falling ;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

//******************************************************************************        
//name:             GUA_Infrared_Receiver_Init 
//introduce:        红外接收初始化 
//******************************************************************************  
void GUA_Infrared_Receiver_Init(void)
{
	GUA_Infrared_Receiver_IO_Init();  //初始化IO
	GUA_Infrared_Receiver_Exti_Init();  //初始化中断配置
}

//******************************************************************************        
//name:             GUA_Infrared_Receiver_GetHighLevelTime  
//introduce:        红外接收获取高电平维持时间
//****************************************************************************** 
static uint16_t GUA_Infrared_Receiver_GetHighLevelTime(void)
{
    uint16_t nGUA_Num = 0;
	//判断是否一直为高电平
while(GPIO_ReadInputDataBit(GUA_INFRARED_RECEIVER_PORT, GUA_INFRARED_RECEIVER_PIN) == Bit_SET)
    {
		//超时超时溢出
        if(nGUA_Num >= 250) 
        {
            return nGUA_Num;
        }
        nGUA_Num++;	 	//计延时20us的次数
        delay_us(20);	//该延时针对外部晶振8000的STM32C8T6核心板，对于不同类型不同外部晶振的开发板需要根据波形图调整延时,保证20us延时       
    }

    return nGUA_Num;
}

//******************************************************************************        
//name:             GUA_Infrared_Receiver_GetLowLevelTime  
//introduce:        红外接收获取低电平维持时间
//****************************************************************************** 
static uint16_t GUA_Infrared_Receiver_GetLowLevelTime(void)
{
    uint16_t nGUA_Num = 0;

	//判断是否一直为低电平
    while(GPIO_ReadInputDataBit(GUA_INFRARED_RECEIVER_PORT, GUA_INFRARED_RECEIVER_PIN) == Bit_RESET)
    {
        if(nGUA_Num >= 500) 
        {
            return nGUA_Num;
        }

        nGUA_Num++;

        delay_us(20) ;//该延时针对外部晶振8000的STM32C8T6核心板，对于不同类型不同外部晶振的开发板需要根据波形图调整延时，保证低电平延时                   
    }

    return nGUA_Num;
}

//******************************************************************************            
//name:             GUA_Infrared_Receiver_Process  
//introduce:        红外接收的处理函数 
// 该函数是关键所在：处理红外信号看接收管OUT引脚电平维持时间，高低电平一定时间后状态变化。
//                  依据电平维持时间，判断：引导码、32位数据···
//******************************************************************************
uint16_t nGUA_Time_Num;
uint8_t nGUA_Data;
uint8_t nGUA_Byte_Num;
uint8_t nGUA_Bit_Num;
uint32_t ContinuousReceiver_Data;  //保存上次捕获的32位原始的数据
//
uint8_t GUA_Infrared_Receiver_Process(void)
{
     nGUA_Time_Num = 0;
     nGUA_Data = 0;
     nGUA_Byte_Num = 0;
     nGUA_Bit_Num = 0;

	//接收引导码9ms的低电平,过滤无用信号>10ms或<8ms
    nGUA_Time_Num = GUA_Infrared_Receiver_GetLowLevelTime();
    if((nGUA_Time_Num > 500) || (nGUA_Time_Num < 400))
    {
//1		Serial_SendString("\r\n 1: error occurred \r\n");     //_________
        return GUA_INFRARED_RECEIVER_ERROR;
    }   
	//接收引导码4.5ms的高电平,过滤无用信号>5ms或<4ms     //250ms时是连续发送信号
    nGUA_Time_Num = GUA_Infrared_Receiver_GetHighLevelTime();
    if((nGUA_Time_Num > 250) || (nGUA_Time_Num < 100))                   //200<=  >=250
    {
//2		Serial_SendString("\r\n 2: error occurred \r\n");     //_________
        return GUA_INFRARED_RECEIVER_ERROR;
    }   
	
	//接收4字节数据（分别有：用户反码、用户码、地址反码、地址码）
    for(nGUA_Byte_Num = 0; nGUA_Byte_Num < 4; nGUA_Byte_Num++)
    {
		//接收位数据（每字节8位）
        for(nGUA_Bit_Num = 0; nGUA_Bit_Num < 8; nGUA_Bit_Num++)
        {
			//接收每bit的前0.56ms的低电平,过滤无用信号>1.2ms或<0.40ms
            nGUA_Time_Num = GUA_Infrared_Receiver_GetLowLevelTime();
            if((nGUA_Time_Num > 60) || (nGUA_Time_Num < 20))
            {
			Serial_SendString("\r\n 3: error occurred \r\n");     //_________
                return GUA_INFRARED_RECEIVER_ERROR;
            }
			//接收每bit的后高电平时长:高电平数据,1.68ms(1.2ms~2.0ms),低电平数据,0.56ms(0.2ms~1ms),过滤其他无用信号
			nGUA_Time_Num = GUA_Infrared_Receiver_GetHighLevelTime();
            if((nGUA_Time_Num >=60) && (nGUA_Time_Num < 100))   //25  50
            {
                nGUA_Data = 1;
            }
            else if((nGUA_Time_Num >=10) && (nGUA_Time_Num < 50))   //50 90
            {
                nGUA_Data = 0;
            }
            else
            {
				if(nGUA_Time_Num == 250)   //红外连续发送情况下，退出循环直接赋予上次的数据
				{
					IR_RepeatFlag = 1;     //连续收发标志置一
					IR_DataFlag = 0;		//单发标志置零
					gGUA_InfraredReceiver_Data = ContinuousReceiver_Data;
					return GUA_INFRARED_RECEIVER_OK;    
				}else{
					Serial_SendString("\r\n 4: error occurred \r\n");     //_________
					return GUA_INFRARED_RECEIVER_ERROR;
				}
            }
			//保存数据
            gGUA_InfraredReceiver_Data <<= 1;   
            gGUA_InfraredReceiver_Data |= nGUA_Data;                        
        }
    }
	IR_DataFlag = 1;     //单次收发标志置一
	IR_RepeatFlag = 0;   //连发标志置零
	ContinuousReceiver_Data = gGUA_InfraredReceiver_Data;
    return GUA_INFRARED_RECEIVER_OK;    
}

//*******************************************************************************
//》》》》》》》》》》》》》》中断处理函数《《《《《《《《《《《《《《《《《《
void EXTI9_5_IRQHandler(void)
{
	if(EXTI_GetITStatus(GUA_INFRARED_RECEIVER_EXTI_LINE) != RESET)
	{
		EXTI_ClearITPendingBit(GUA_INFRARED_RECEIVER_EXTI_LINE);
		EXTI->IMR &= ~(GUA_INFRARED_RECEIVER_EXTI_LINE);
	  
		if(GUA_Infrared_Receiver_Process() == GUA_INFRARED_RECEIVER_OK) //如果捕获到有效数据
		{
			down16=gGUA_InfraredReceiver_Data;
			up16=gGUA_InfraredReceiver_Data>>16;
			//-----------从上到下依次为用户反码、用户码、地址反码、地址码
			IR_RECEIVE[3]=down16;
			IR_RECEIVE[2]=(down16>>8);
			IR_RECEIVE[1]=up16;
			IR_RECEIVE[0]=(up16>>8);
//		Show_Data();       		 //显示红外接收到的数据
		}	
		else if(GUA_Infrared_Receiver_Process() == GUA_INFRARED_RECEIVER_ERROR)
		{ 											//否则、串口显示已经累加的时间(uS)和 解码错误提示
//			Serial_SendNumber(nGUA_Time_Num,4);			
			Serial_SendString("*");
			gGUA_InfraredReceiver_Data=0;
		}

	}
	EXTI->IMR|=(GUA_INFRARED_RECEIVER_EXTI_LINE);
}

/***********************调试键码的函数（串口输出）*********************************
  *
  *函数： 显示出已经捕获得到的红外数据，
  *		  如果解码成功，可以获得红外数据（地址码+地址反码+用户码+用户反码）
  *		  （通过串口发送相关信息，使用Serial_SendNumber（）可以在调试窗口文本类得到十进制格式，
  *		    再将数据十进制换算成十六进制就可以进行比较和传递。）
  *参数：无
**/
void Show_Data(void)
{
	Serial_SendArray(IR_RECEIVE,32);
	Serial_SendString("\r\n 读取成功");
	Serial_SendString("\r\n 地址码:");
	Serial_SendNumber( IR_RECEIVE[3],4);
	Serial_SendString("\r\n 地址反码:");
	Serial_SendNumber( IR_RECEIVE[2],4);
	Serial_SendString("\r\n 用户码:");
	Serial_SendNumber( IR_RECEIVE[1],4);
	Serial_SendString("\r\n 用户反码:");
	Serial_SendNumber( IR_RECEIVE[0],4);
}
/************************************五个可获取红外相关数据的函数***********************************
  * @brief  红外遥控获取收到数据帧标志位
  * @param  无
  * @retval 是否收到数据帧，1为收到，0为未收到
  */
uint8_t IR_GetDataFlag(void)
{
	if(IR_DataFlag)
	{
		IR_DataFlag=0;
		return 1;
	}
	return 0;
}
/**
  * @brief  红外遥控获取收到连发帧标志位
  * @param  无
  * @retval 是否收到连发帧，1为收到，0为未收到
  */
uint8_t IR_GetRepeatFlag(void)
{
	if(IR_RepeatFlag)
	{
		IR_RepeatFlag=0;
		return 1;
	}
	return 0;
}
/**
  * @brief  红外遥控获取收到的地址数据
  * @param  无
  * @retval 收到的地址码数据
  */
uint8_t IR_GetAddress(void)
{
	return IR_RECEIVE[0];
}
/**
  * @brief  红外遥控获取收到的命令数据
  * @param  无
  * @retval 收到的用户码数据
  */
uint8_t IR_GetUserCode(void)
{
	return IR_RECEIVE[2];
}


/***
  * @brief  为获得的红外用户码（命令）数据赋予一个数字身份
  * @param  无
  * @retval 收到的用户码的新身份
  */
uint8_t IR_CommandSymbol(void)
{
	uint8_t Num;
	switch(IR_RECEIVE[2])
	{
		case IR_0: Num= 0;break;            //0 代表 0键：
		case IR_1: Num= 1;break;           //1 代表 1键:	
		case IR_2: Num= 2;break;           //2 代表 2键:
		case IR_3: Num= 3;break;           //3 代表 3键: 	
		case IR_4: Num= 4;break;           //4 代表 4键:
		case IR_5: Num= 5;break;           //5 代表 5键:	
		case IR_6: Num= 6;break;           //6 代表 6键:
		case IR_7: Num= 7;break;           //7 代表 7键:
		case IR_8: Num= 8;break;           //8 代表 8键:
		case IR_9: Num= 9;break;           //9 代表 9键:
		case IR_POWER: Num= 10;break;       //代表开关键:
		case IR_MODE:  Num= 11;break;       // 代表模式键:		
		case IR_START_STOP:  Num= 12;break;  //代表静音键:
		case IR_MUTE: Num= 13;break;  		//代表暂停键:
		case IR_LAST:   Num= 14;break;      // 代表上一个键:	
		case IR_NEXT: Num= 15;break;        // 代表 下一个键:
		case IR_EQ:   Num= 16;break;        // 代表 EQ键:
		case IR_VOL_MINUS: Num= 17;break;   //代表 VolADD键	
		case IR_VOL_ADD:   Num= 18;break;   // 代表 VolDOW键
		case IR_RPT: Num= 19;break;         // 代表 RPT键:		
		case IR_USD: Num= 20;break;			// 代表 U_SD键:
		default :break;
	}
	return Num;	
}

//		if(IR_GetDataFlag())  //若红外单发
//		{
//			LED2_Turn();
//			if(IR_CommandSymbol() == 4)
//			{
//				Serial_SendString("\r\n X左转 ");   // 打印按键0到9
//				Run_motor_X(1,360);

//			}
//			else if(IR_CommandSymbol() == 6)
//			{
//				Serial_SendString("\r\n X右转");
//				Run_motor_X(0,360);
//			}
//			if(IR_CommandSymbol() == 2)
//			{
//				Serial_SendString("\r\n Y上转 ");   // 打印按键0到9
//				Run_motor_Y(1,180);

//			}
//			else if(IR_CommandSymbol() == 8)
//			{
//				Serial_SendString("\r\n Y下转");
//				Run_motor_Y(0,180);
//			}
//			if(IR_CommandSymbol() == 11)
//			{
//				Serial_SendString("\r\n Z上转");   // 打印按键0到9
//				Run_motor_Z(1,180);

//			}
//			else if(IR_CommandSymbol() == 17)
//			{
//				Serial_SendString("\r\n Z下转");
//				Run_motor_Z(0,180);
//			}
//			if(IR_CommandSymbol() == 13)
//			{
//				Serial_SendString("\r\n 夹爪开");   // 打印按键0到9
//				Servo_control(1);

//			}
//			else if(IR_CommandSymbol() == 15)
//			{
//				Serial_SendString("\r\n 夹爪关");
//				Servo_control(0);
//			}		
//		
//		}		
