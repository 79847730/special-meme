#ifndef __IR_H_
#define __IR_H_

#include "stm32f10x.h"                  // Device header

//红外接收引脚
#define GUA_INFRARED_RECEIVER_PORT               GPIOB
#define GUA_INFRARED_RECEIVER_PIN                GPIO_Pin_5
#define GUA_INFRARED_RECEIVER_RCC                RCC_APB2Periph_GPIOB

//中断
#define GUA_INFRARED_RECEIVER_EXTI_LINE          EXTI_Line5
#define GUA_INFRARED_RECEIVER_PORTSOURCE         GPIO_PortSourceGPIOB
#define GUA_INFRARED_RECEIVER_PINSOURCE          GPIO_PinSource5

#define TRUE            0
#define FALSE           1

#define GUA_INFRARED_RECEIVER_OK                0
#define GUA_INFRARED_RECEIVER_ERROR             1

/*********************外部变量************************/
extern uint32_t gGUA_InfraredReceiver_Data;          //一个接收红外原始数据的变量（32位）

/********************* 函数声明 ************************/ 
extern void GUA_Infrared_Receiver_Init(void);
extern uint8_t GUA_Infrared_Receiver_Process(void);
void Show_Data(void);


//**************************************************************
//》》》》》》》》》》能在主函数里调用的函数《《《《《《《《《《《
//**************************************************************

uint8_t IR_GetDataFlag(void);     	//  是否按一次	（单发）
uint8_t IR_GetRepeatFlag(void);   	//	是否为连按	（连发）
uint8_t IR_GetAddress(void);		// 	地址码
uint8_t IR_GetUserCode(void);		//	用户码（按键命令）
uint8_t IR_CommandSymbol(void);   	//	将用户码转换出一个对应的数字身份

//***********************************************************************
//***********************************************************************
//从“调试键码的函数”获得相应用户码，并转换位16进制后，对遥控发送的键码(用户码)进行宏定义
#define IR_POWER		0xA2  //1602
#define IR_MODE			0x62  //0098
#define IR_START_STOP	0xe2  //0226
#define IR_MUTE			0x22  //0034
#define IR_LAST			0x02  //0002
#define IR_NEXT			0xc2  //0194
#define IR_EQ			0xE0  //0224
#define IR_VOL_MINUS	0xA8  //0168
#define IR_VOL_ADD		0x90 //0144
#define IR_0			0x68  //0104
#define IR_RPT			0x92  //0158
#define IR_USD			0xB0  //0176
#define IR_1			0x30
#define IR_2			0x18
#define IR_3			0x7A
#define IR_4			0x10
#define IR_5			0x38
#define IR_6			0x5A
#define IR_7			0x42
#define IR_8			0x4A
#define IR_9			0x52

#endif


