#include "stm32f10x.h"                  // Device header
#include "Delay.h"   
#include "LED.h"



void Key_Init(void)
{
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOA,ENABLE);//开启时钟
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_AFIO,ENABLE);//开启复用
	
	GPIO_InitTypeDef GPIO_Initstructure;//结构体
	GPIO_Initstructure.GPIO_Mode=GPIO_Mode_IPU ;//模式
	GPIO_Initstructure.GPIO_Pin =GPIO_Pin_15 ;//引脚
	GPIO_Initstructure.GPIO_Speed =GPIO_Speed_50MHz ;//频率
	GPIO_Init (GPIOA, &GPIO_Initstructure);//
	
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource15);
//	
//	EXTI_InitTypeDef EXTI_Initstructure;
//	EXTI_Initstructure.EXTI_Line =EXTI_Line15;
//	EXTI_Initstructure.EXTI_LineCmd =ENABLE;
//	EXTI_Initstructure.EXTI_Mode =EXTI_Mode_Interrupt;
//	EXTI_Initstructure.EXTI_Trigger =EXTI_Trigger_Falling;
//	EXTI_Init (&EXTI_Initstructure);
//	
////	NVIC_InitTypeDef NVIC_Initstructure;
////	NVIC_Initstructure.NVIC_IRQChannel= EXTI15_10_IRQn;
////	NVIC_Initstructure.NVIC_IRQChannelCmd =ENABLE;
////	NVIC_Initstructure.NVIC_IRQChannelPreemptionPriority =1;//抢占优先级
////	NVIC_Initstructure.NVIC_IRQChannelSubPriority =1;//响应优先级
////	NVIC_Init (&NVIC_Initstructure);
}

uint8_t KeyNum = 1;

/*
开关中断函数
*/
//void EXTI15_10_IRQHandler(void)
//{
//	if(EXTI_GetITStatus(EXTI_Line15) ==SET)
//	{	
//		Delay_ms (10);
//		LED1_Turn ();
//		EXTI_ClearITPendingBit(EXTI_Line15);
//	}
//}

uint8_t Key_GetNum(void)
{
	return KeyNum;
}

