#include "stm32f10x.h"                  // Device header
#include "LED.h"
#include "DELAY.h"
#include "PWM.h"
#include "MOTOR.h"

#include "SERIAL.h"

extern uint16_t  reality_x_angle,reality_y_angle,reality_z_angle;	//ʵ�ʻ�е�۵ĽǶ� 

void LIMIT14_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_AFIO,ENABLE);//��������
	
	GPIO_InitTypeDef GPIO_Initstructure;//�ṹ��
	GPIO_Initstructure.GPIO_Mode=GPIO_Mode_IPU ;//ģʽ
	GPIO_Initstructure.GPIO_Pin =GPIO_Pin_14;//����
	GPIO_Initstructure.GPIO_Speed =GPIO_Speed_50MHz ;//Ƶ��
	GPIO_Init (GPIOB, &GPIO_Initstructure);//
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource14);
	EXTI_InitTypeDef EXTI_Initstructure;
	EXTI_Initstructure.EXTI_Line =EXTI_Line14;
	EXTI_Initstructure.EXTI_LineCmd =ENABLE;
	EXTI_Initstructure.EXTI_Mode =EXTI_Mode_Interrupt;
	EXTI_Initstructure.EXTI_Trigger =EXTI_Trigger_Falling;
	EXTI_Init (&EXTI_Initstructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_Initstructure;
	NVIC_Initstructure.NVIC_IRQChannel= EXTI15_10_IRQn;
	NVIC_Initstructure.NVIC_IRQChannelCmd =ENABLE;
	NVIC_Initstructure.NVIC_IRQChannelPreemptionPriority =1;//��ռ���ȼ�
	NVIC_Initstructure.NVIC_IRQChannelSubPriority =2;//��Ӧ���ȼ�
	NVIC_Init (&NVIC_Initstructure);

}

void LIMIT15_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_AFIO,ENABLE);//��������
	
	GPIO_InitTypeDef GPIO_Initstructure;//�ṹ��
	GPIO_Initstructure.GPIO_Mode=GPIO_Mode_IPU ;//ģʽ
	GPIO_Initstructure.GPIO_Pin =GPIO_Pin_15;//����
	GPIO_Initstructure.GPIO_Speed =GPIO_Speed_50MHz ;//Ƶ��
	GPIO_Init (GPIOB, &GPIO_Initstructure);//
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource15);
	EXTI_InitTypeDef EXTI_Initstructure;
	EXTI_Initstructure.EXTI_Line =EXTI_Line15;
	EXTI_Initstructure.EXTI_LineCmd =ENABLE;
	EXTI_Initstructure.EXTI_Mode =EXTI_Mode_Interrupt;
	EXTI_Initstructure.EXTI_Trigger =EXTI_Trigger_Falling;
	EXTI_Init (&EXTI_Initstructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_Initstructure;
	NVIC_Initstructure.NVIC_IRQChannel= EXTI15_10_IRQn;
	NVIC_Initstructure.NVIC_IRQChannelCmd =ENABLE;
	NVIC_Initstructure.NVIC_IRQChannelPreemptionPriority =1;//��ռ���ȼ�
	NVIC_Initstructure.NVIC_IRQChannelSubPriority =1;//��Ӧ���ȼ�
	NVIC_Init (&NVIC_Initstructure);
}

void LIMIT_Init(void)
{
	LIMIT14_Init();
	LIMIT15_Init();
}


void EXTI15_10_IRQHandler (void)
{
	if(EXTI_GetITStatus(EXTI_Line14) ==SET)
		{	
			PWM_Compare2(0);
			printf("The Y manipulator is in place \r\n");
			if(Motor_reset_flag()==0)
			{
				Run_motor_Y(0,5);
			}
			EXTI_ClearITPendingBit(EXTI_Line14);		
		}
	if(EXTI_GetITStatus(EXTI_Line15) ==SET)
		{	
			PWM_Compare3(0);
			printf("The Z manipulator is in place \r\n");
			if(Motor_reset_flag()==0)
			{
				Run_motor_Z(1,5);
			}
			EXTI_ClearITPendingBit(EXTI_Line15);
		}
}



	
