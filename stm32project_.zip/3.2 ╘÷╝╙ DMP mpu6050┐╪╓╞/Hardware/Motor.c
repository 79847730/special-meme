#include "PWM.h"
#include "motor.h"
#include "TIMER.h"
#include "LIMIT.h"
#include "LED.h"
#include "DELAY.h"
#include "SERIAL.h"

#include "gui.h"
#include "lcd.h"
#include "test.h"

#include "servo.h"
//#include "led.h"
extern double x_angle,y_angle,z_angle;		//轴需要的角度 
extern uint16_t  reality_x_angle,reality_y_angle,reality_z_angle;	//实际机械臂的角度 
extern float  x,y,z,g;		//轴需要的角度 
extern 	uint8_t state;	
/******引脚的初始化有使能和3个电机的方向引脚********/
void GPIO_Motor_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	// 对应IO端口时钟使能
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);

	// 对于A4988驱动的步进电机，初始化DIR引脚与ENABLE引脚(ENABLE与DIR都在GPIOC口)
	GPIO_InitStructure.GPIO_Pin = Motor_ENABLE|MotorX_DIR|MotorY_DIR|MotorZ_DIR;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	// 推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOA,Motor_ENABLE);
	GPIO_SetBits(GPIOA,MotorX_DIR);
	GPIO_SetBits(GPIOA,MotorY_DIR);
	GPIO_SetBits(GPIOA,MotorZ_DIR);
}

/***************************************
**********上电根据限位开关复位**********/
uint8_t flag=0;

void Motor_reset(void)
{
	x=40;y=0;z=256;g=0;state=3;
	reality_x_angle=0,reality_y_angle=72,reality_z_angle=208;	//实际机械臂的角度 
	printf("(%d,%d,%d,%d,%d)\r\n",(int)x,(int)y,(int)z,(int)g,state);
	printf("The manipulator is resetting.......\r\n");
	flag=1;
	uint8_t i=0;
	while((GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14) == Bit_SET) || (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15) == Bit_SET))
		{
			
		if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14) == Bit_SET)
			{
				Run_motor_Y(1,10);
			}
		if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15) == Bit_SET)
			{
				Run_motor_Z(0,10);
			}
		//	delay_ms ();
		LCD_Show_pmgressbar(90,40,35,200,i,RED,BLACK);
		i++;
		}
		Run_motor_Y(0,5);
		Run_motor_Z(1,5);
		Servo_control(0);
		flag=0;
	printf("(%d,%d,%d,%d,%d)\r\n",(int)x,(int)y,(int)z,(int)g,0);
	//printf("(%d,%d,%d,%d,%d)\r\n",(int)x,(int)y,(int)z,(int)g,state);
}

uint8_t  Motor_reset_flag( void )
{
	return flag;
}
/***********************************
*********方向函数**输入0**1**********
****1是顺时针方向**0逆时针反向*******
************************************/

void Motor_DIR_X(uint8_t X_DIR)
{
	if(X_DIR==1)
	{
	GPIO_ResetBits(GPIOA,MotorX_DIR);
	}
	if (X_DIR==0)
	{
	GPIO_SetBits(GPIOA,MotorX_DIR);
	}
}

void Motor_DIR_Y(uint8_t Y_DIR)
{
	if(Y_DIR==1)
	{
	GPIO_ResetBits(GPIOA,MotorY_DIR);
	}
	if (Y_DIR==0)
	{
	GPIO_SetBits(GPIOA,MotorY_DIR);	
	}
}
void Motor_DIR_Z(uint8_t Z_DIR)
{
	if(Z_DIR==1)
	{
	GPIO_ResetBits(GPIOA,MotorZ_DIR);
	}
	if (Z_DIR==0)
	{
	GPIO_SetBits(GPIOA,MotorZ_DIR);
	}
}

///******************************************************
//*********小封装 输入方向输入脉冲***********************/
void Run_motor_X(uint8_t X_DIR,uint16_t angle)
{
	if(X_DIR==1)
	{
	GPIO_ResetBits(GPIOA,MotorX_DIR);
	}
	if (X_DIR==0)
	{
	GPIO_SetBits(GPIOA,MotorX_DIR);
	}
	Motor_angle_X(angle);
}

void Run_motor_Y(uint8_t Y_DIR,uint16_t angle)
{
	if(Y_DIR==1)
	{
	GPIO_ResetBits(GPIOA,MotorY_DIR);
	}
	if (Y_DIR==0)
	{
	GPIO_SetBits(GPIOA,MotorY_DIR);	
	}
	Motor_angle_Y(angle);
}

void Run_motor_Z(uint8_t Z_DIR,uint16_t angle)
{
	if(Z_DIR==1)
	{
	GPIO_ResetBits(GPIOA,MotorZ_DIR);
	}
	if (Z_DIR==0)
	{
	GPIO_SetBits(GPIOA,MotorZ_DIR);
	}
	Motor_angle_Z(angle);
}


/*****************************
***输入机械臂角度会输出对应脉冲***
******************************/
void Motor_angle_X(uint16_t angle)
{
	angle=((angle*4.7/1.8)*32);
	Motor_X(angle);
}

void Motor_angle_Y(uint16_t angle)
{
	angle=((angle*5/1.8)*32);
	Motor_Y(angle);
}

void Motor_angle_Z(uint16_t angle)
{
	angle=((angle*5/1.8)*32);
	Motor_Z(angle);
}

/**************************************************
*************输入脉冲个数**************************
***********定时器计脉冲个数***********************
***********步进电机转固定角度*********************
**************************************************/

extern uint16_t speed;
uint8_t Status_flag_x,Status_flag_y,Status_flag_z;

uint8_t State_motor ()
{
	uint8_t State;
	if((Status_flag_x==1) || (Status_flag_y==1) || (Status_flag_z==1))
	{
	State=1;
	}
	else if((Status_flag_x==0) && (Status_flag_y==0) && (Status_flag_z==0))
	{
	State=0;
	}
	return State;
}

//*************3电机停止函数*******************
void  Stop_motor_X(void )
{
	Status_flag_x=0;
	state=State_motor();
	PWM_Compare1(0);
	TIM_Cmd(TIM3, DISABLE);
	TIM_ITConfig(TIM3, TIM_IT_Update, DISABLE); 	//关闭TIM4更新中断
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
}

void  Stop_motor_Y(void )
{
		Status_flag_y=0;
	state=State_motor();
	TIM_Cmd(TIM4, DISABLE);
	PWM_Compare2(0);
	TIM_ITConfig(TIM4, TIM_IT_Update, DISABLE); 	//关闭TIM4更新中断
	TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
}


void  Stop_motor_Z(void )
{	
	Status_flag_z=0;
	state=State_motor();
	TIM_Cmd(TIM5, DISABLE);
	PWM_Compare3(0);
	TIM_ITConfig(TIM5, TIM_IT_Update, DISABLE); 	//关闭TIM4更新中断
	TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
}


//3路脉冲个数控制

void Motor_X(uint32_t PulseNum)
{
		Status_flag_x=1;
		state=State_motor();
		Timer3_Init(PulseNum);		//初始化从定时器
  		TIM_Cmd(TIM3, ENABLE);		//使能从定时器
		PWM_Compare1(speed/2-1);
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);	//清除中断标志位
		TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);	//使能更新中断
}

void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
	Status_flag_x=0;
	state=State_motor();
	PWM_Compare1(0);
	TIM_Cmd(TIM3, DISABLE);
	TIM_ITConfig(TIM3, TIM_IT_Update, DISABLE); 	//关闭TIM4更新中断
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}

/************x轴电机定时器4************************/

void Motor_Y(u32 PulseNum)
{
	Status_flag_y=1;
	state=State_motor();
	Timer4_Init(PulseNum);  
    TIM_Cmd(TIM4, ENABLE);	
	PWM_Compare2(speed/2-1);
	TIM_ClearITPendingBit(TIM4,TIM_IT_Update);	//清除中断标志位
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);	//使能更新中断
}

void TIM4_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
	{
	Status_flag_y=0;
	state=State_motor();
	TIM_Cmd(TIM4, DISABLE);
	PWM_Compare2(0);
	TIM_ITConfig(TIM4, TIM_IT_Update, DISABLE); 	//关闭TIM4更新中断
	TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
	}
}

/**************y轴电机定时器5*****************************/

void Motor_Z(u32 PulseNum)
{
	Status_flag_z=1;
	state=State_motor();
	Timer5_Init(PulseNum);  
    TIM_Cmd(TIM5, ENABLE);	
	PWM_Compare3(speed/2-1);
	TIM_ClearITPendingBit(TIM5,TIM_IT_Update);	//清除中断标志位
	TIM_ITConfig(TIM5,TIM_IT_Update,ENABLE);	//使能更新中断
}

void TIM5_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM5, TIM_IT_Update) == SET)
	{
	Status_flag_z=0;
	state=State_motor();
	TIM_Cmd(TIM5, DISABLE);
	PWM_Compare3(0);
	TIM_ITConfig(TIM5, TIM_IT_Update, DISABLE); 	//关闭TIM4更新中断
	TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
	}
}

/**************z轴电机定时器6*****************************/


