#ifndef __MOTOR_H
#define __MOTOR_H	 
#include "stm32f10x.h"                  // Device header

#define Motor_ENABLE 	GPIO_Pin_4			// 低电平使能

#define MotorX_DIR		GPIO_Pin_5
#define MotorY_DIR		GPIO_Pin_6
#define MotorZ_DIR		GPIO_Pin_7

void GPIO_Motor_Init(void);
void Motor_reset(void);

uint8_t Motor_reset_flag( void );
uint8_t State_motor (void);

void Motor_X(uint32_t PulseNum);
void Motor_Y(u32 PulseNum);
void Motor_Z(u32 PulseNum);
void Motor_DIR_X(uint8_t X_DIR);
void Motor_DIR_Y(uint8_t Y_DIR);
void Motor_DIR_Z(uint8_t Z_DIR);
void Motor_angle_X(uint16_t angle);
void Motor_angle_Y(uint16_t angle);
void Motor_angle_Z(uint16_t angle);
void Run_motor_X(uint8_t X_DIR,uint16_t angle);
void Run_motor_Y(uint8_t Y_DIR,uint16_t angle);
void Run_motor_Z(uint8_t Z_DIR,uint16_t angle);
void  Stop_motor_X(void);
void  Stop_motor_Y(void);
void  Stop_motor_Z(void);
#endif
