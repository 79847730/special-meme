#ifndef __PWM_H
#define __PWM_H
#include "stm32f10x.h"                  // Device header

void TIM1_config(void);
void TIM2_config(u32 Cycle);

	
void PWM_Compare1(uint16_t Compare);
void PWM_Compare2(uint16_t Compare);  
void PWM_Compare3(uint16_t Compare);  
	
void Servo_PWM_Compare1(uint16_t Compare);		//�����pwm���ͨ��3
	
#endif
