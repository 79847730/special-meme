#include "PWM.h"
#include "SERVO.h"

void Servo_Init(void)
{
	TIM1_config();
}


void Servo_SetAngle(float Angle)
{
	Servo_PWM_Compare1(Angle / 180 * 2000 + 500);
}

uint8_t flag_Servo=0;

void Servo_control( uint8_t state)
{
	//flag_Servo=state;
	if(flag_Servo!=state)
	{
		if(state==1)
			{
			Servo_SetAngle(170);
			flag_Servo=1;
			}
		else if(state==0)
			{	
			Servo_SetAngle(120);
			flag_Servo=0;
			}
	}

}

uint8_t state_Servo( void )
{
	return flag_Servo;
}
