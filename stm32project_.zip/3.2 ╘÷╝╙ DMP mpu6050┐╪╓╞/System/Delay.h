#ifndef __DELAY_H
#define __DELAY_H

void delay_us(u32 nus);
void delay_ms(u16 nms);

#endif
