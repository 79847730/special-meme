#include "INVERSE.h"
#include "stm32f10x.h"                  // Device header
#include "Motor.h"
#include "SERIAL.h"
#include "math.h"
#define PI 3.141592654

/*	  * z   *y
	  *   *
	  * *
	  * * * *x
笛卡尔空间坐标系*/

extern float  x_angle,y_angle,z_angle;
extern uint16_t reality_x_angle,reality_y_angle,reality_z_angle;	//实际机械臂的角度 
extern uint16_t rotation_x_angle,rotation_y_angle,rotation_z_angle;	//计算出机械臂需要的角度 

float length_fore=120,length_rear=120,length_base=120;  //机械臂各个关节长度  底部 后臂 前臂 
 
void Inverse_angle(float x,float y,float z)
{
	float projection,difference,subline; 
	projection=sqrt((x*x)+(y*y));
	//printf("投影长度%f  \r\n",projection);
	if(x>=0 && y>=0)
	{
		//printf("第一象限 \r\n");
		x_angle=atan(y/x);
		x_angle=x_angle*180/PI;
		if(x==0 && y>0)
		{
		x_angle=90;
		}
	}
	else if(x<0 && y>=0)
	{
		//printf("第二象限 \r\n");
		x_angle=atan(x/y);
		x_angle=x_angle*180/PI;
		x_angle=fabs(x_angle)+90;
		if(y==0 && x<0)
		{
		x_angle=180;
		}
	}
	else if(x<=0 && y<0)
	{
		//printf("第三象限 \r\n");
		x_angle=atan(y/x);
		x_angle=x_angle*180/PI;
		x_angle=x_angle+180;
		if(x==0 && y<0)
		{
		x_angle=270;
		}
	}
	else if(x>=0 && y<0)
	{
		//printf("第四象限 \r\n");
		x_angle=atan(x/y);
		x_angle=x_angle*180/PI;
		x_angle=fabs(x_angle)+270;
		if(y==0 && x>0)
		{
		x_angle=360;
		}
	}
	if(z == length_base)
	{	
		//printf("水平 \r\n");
		z_angle=acos(((length_rear*length_rear)+(projection*projection)-(length_fore*length_fore)) 
							/ (2*length_rear*projection));
		z_angle=(z_angle*180/PI)+90;
		y_angle=acos(((length_rear*length_rear)+(length_fore*length_fore)-(projection*projection)) 
							/ (2*length_rear*length_fore));
		y_angle=(y_angle*180)/PI;
	}
	else if ( z > length_base)
	{
		//printf("高平\r\n");
		difference=z-length_base;
		subline=sqrt((difference*difference)+(projection*projection));
		//printf("差值长度%f  \r\n",difference);
		//printf("辅助线长度%f  \r\n",subline);
		float z_angle1,z_angle2;
		z_angle1=acos(((subline*subline)+(projection*projection)-(difference*difference)) 
							/ (2*subline*projection));
		z_angle2=acos(((subline*subline)+(length_rear*length_rear)-(length_fore*length_fore)) 
							/ (2*subline*length_rear));	
		z_angle=((z_angle1+z_angle2)*180/PI)+90;
		y_angle=acos(((length_fore*length_fore)+(length_rear*length_rear)-(subline*subline)) 
							/ (2*length_fore*length_rear));	
		y_angle=y_angle*180/PI;					
	}
	else if ( z < length_base)
	{
		//printf("低位 \r\n");
		difference=length_base-z;
		subline=sqrt((difference*difference)+(projection*projection));
		//printf("差值长度%f \r\n",difference);
		//printf("辅助线长度%f  \r\n",subline);
		float z_angle1,z_angle2;
		z_angle1=acos(((subline*subline)+(length_rear*length_rear)-(length_fore*length_fore)) 
							/ (2*subline*length_rear));
		z_angle2=acos(((subline*subline)+(difference*difference)-(projection*projection)) 
							/ (2*subline*difference));
		z_angle=(z_angle1+z_angle2)*180/PI;
	
		y_angle=acos(((length_fore*length_fore)+(length_rear*length_rear)-(subline*subline)) 
							/ (2*length_fore*length_rear));	
		y_angle=y_angle*180/PI;					
	}
	//printf("x角度%f  \r\n",x_angle);
	//printf("y角度%f  \r\n",y_angle);
	//printf("z角度%f  \r\n",z_angle);
	rotation_x_angle=(int)x_angle;
	rotation_y_angle=(int)y_angle;
	rotation_z_angle=(int)z_angle;
}


void Radial_Move (void)
{
	if (rotation_x_angle>reality_x_angle)	
	{
		//printf("X目标角度大于实际角度\r\n");
		if((rotation_x_angle-reality_x_angle)<((360-rotation_x_angle)+reality_x_angle))
		{
		Motor_DIR_X(1);
		int temporary_x_angle=rotation_x_angle-reality_x_angle;
		Motor_angle_X (temporary_x_angle);
		reality_x_angle=rotation_x_angle;
		//printf("X逆时针转的角度：%d\r\n",temporary_x_angle);
		}
		else if((rotation_x_angle-reality_x_angle)>((360-rotation_x_angle)+reality_x_angle))
		{
			Motor_DIR_X(0);
			int temporary_x_angle;
			temporary_x_angle=((360-rotation_x_angle)+reality_x_angle);
			Motor_angle_X (temporary_x_angle);
			reality_x_angle=rotation_x_angle;
			//printf("X顺时针转的角度：%d\r\n",temporary_x_angle);
		}
		else if((rotation_x_angle-reality_x_angle)==(360-rotation_x_angle+reality_x_angle))
		{
			//printf("相等\r\n");
			Motor_DIR_X(0);
			Motor_angle_X (180);
			reality_x_angle=rotation_x_angle;
			//printf("X顺时针转的角度：%d\r\n",180);
		}
	}
	else if (rotation_x_angle<reality_x_angle)	
	{
	//	printf("X目标角度小于实际角度\r\n");
		if((reality_x_angle-rotation_x_angle)<((360-reality_x_angle)+rotation_x_angle))
		{
		Motor_DIR_X(0);
		int temporary_x_angle=reality_x_angle-rotation_x_angle;
		Motor_angle_X (temporary_x_angle);
		reality_x_angle=rotation_x_angle;
		//printf("X顺时针转的角度：%d\r\n",temporary_x_angle);
		}
		if((reality_x_angle-rotation_x_angle)>((360-reality_x_angle)+rotation_x_angle))
		{
		Motor_DIR_X(1);
		int temporary_x_angle=(360-reality_x_angle)+rotation_x_angle;
		Motor_angle_X (temporary_x_angle);
		reality_x_angle=rotation_x_angle;
		//printf("X逆时针转的角度：%d\r\n",temporary_x_angle);
		}
		else if((reality_x_angle-rotation_x_angle)==((360-reality_x_angle)+rotation_x_angle))
		{
			//printf("X目标角度与实际角度相等\r\n");
			Motor_DIR_X(0);
			Motor_angle_X (180);
			reality_x_angle=rotation_x_angle;
			//printf("X顺时针转的角度：%d\r\n",180);
		}
	}	
	if (rotation_z_angle>reality_z_angle)
	{
		//printf("Z目标角度大于实际角度\r\n");
		Motor_DIR_Z(0);
		int temporary_z_angle=rotation_z_angle-reality_z_angle;
		Motor_angle_Z (temporary_z_angle);
		reality_y_angle=reality_y_angle-temporary_z_angle;
		reality_z_angle=rotation_z_angle;
		//printf("Z逆时针转的角度：%d\r\n",temporary_z_angle);
		//printf("Y的角度：%d\r\n",reality_y_angle);
	}
	else if (rotation_z_angle<reality_z_angle)
	{
		//printf("Z目标角度小于实际角度\r\n");
		Motor_DIR_Z(1);
		int temporary_z_angle=reality_z_angle-rotation_z_angle;
		Motor_angle_Z (temporary_z_angle);
		reality_z_angle=rotation_z_angle;
		reality_y_angle=reality_y_angle+temporary_z_angle;
		
		//printf("Z顺时针转的角度：%d\r\n",temporary_z_angle);
		//printf("Y的角度：%d\r\n",reality_y_angle);
	}
	//printf("Y的角度：%d\r\n",reality_y_angle);
	if (rotation_y_angle>reality_y_angle)
	{
		//printf("Y目标角度大于实际角度\r\n");
		Motor_DIR_Y(1);
		int temporary_y_angle=rotation_y_angle-reality_y_angle;
		Motor_angle_Y (temporary_y_angle);
		reality_y_angle=rotation_y_angle;
		//printf("Y逆时针转的角度：%d\r\n",temporary_y_angle);
	}
	else if (rotation_y_angle<reality_y_angle)
	{
		//printf("Y目标角度小于实际角度\r\n");
		Motor_DIR_Y(0);
		int temporary_y_angle=reality_y_angle-rotation_y_angle;
		Motor_angle_Y (temporary_y_angle);
		reality_y_angle=rotation_y_angle;
		//printf("Y顺时针转的角度：%d\r\n",temporary_y_angle);
	}

}
