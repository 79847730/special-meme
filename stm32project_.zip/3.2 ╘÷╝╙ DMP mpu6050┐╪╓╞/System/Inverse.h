#ifndef __INVERSE_H_
#define __INVERSE_H_

void Inverse_angle(float x,float y,float z);
void Radial_Move(void);

#endif
