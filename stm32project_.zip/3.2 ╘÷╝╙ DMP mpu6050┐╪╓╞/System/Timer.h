#ifndef __TIMER_H
#define __TIMER_H	 
#include "stm32f10x.h"                  // Device header

void Timer3_Init(u32 Cycle);
void Timer4_Init(u32 Cycle);
void Timer5_Init(u32 Cycle);

#endif
