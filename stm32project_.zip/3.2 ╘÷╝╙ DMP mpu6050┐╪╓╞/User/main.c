#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include "lcd.h"
#include "test.h"
#include "Motor.h"
#include "SERIAL.h"
#include "PWM.h"
#include "LIMIT.h"
#include "servo.h"
#include "led.h"
#include "mpu6050.h"
#include "string.h"
#include "gui.h"
#include "INVERSE.h"
#include "servo.h"
#include "lcd.h"
#include "test.h"
#include "PWM.h"
#include "Motor.h"

uint8_t mpu6050_flag;
uint8_t mode=0;//模式 1就进入mpu6050
uint16_t  speed=250;//速度
uint8_t state;//机械臂状态是否在运行
float Pitch,Roll,Yaw;//mpu6050 俯仰角 翻滚角 偏航角
float  x=0,y=0,z=0,g=0;	//3轴坐标 xyz夹爪状态g
float x_angle=0,y_angle=0,z_angle=0;	//计算需要输入的角度 
uint16_t reality_x_angle=0,reality_y_angle=0,reality_z_angle=0;	//实际机械臂的角度 
uint16_t rotation_x_angle=0,rotation_y_angle=0,rotation_z_angle=0;	//计算出机械臂需要的角度 


void  MPU6050_control (uint8_t flag)
{
	if(flag==1)
	{	
		if(mpu6050_flag==1)
		{
		interface_6050();
		MPU6050_initialize();     //=====MPU6050初始化	
		DMP_Init();
		immobile_interface_6050();
		mpu6050_flag=0;
		}
		Read_DMP(&Pitch,&Roll,&Yaw);
		refresh_interface_6050 (Pitch, Roll, Yaw);
		if(Pitch!=0)
			{
			LED2_ON ();	
			printf("\n\r Pitch=%.2f  Roll=%.2f  Roll=%.2f \n\r",Pitch,Roll,Yaw); 
			if(Pitch<-20){
			Run_motor_Z(0,5);
			if(Pitch<-40)Run_motor_Y(1,4);}
			if(Pitch>60){
			Run_motor_Z(1,5);
			if(Pitch>70)Run_motor_Y(0,4);}
			if(Roll<-20)
			Run_motor_X(1,5);
			if(Roll>20)
			//Stop_motor_X();
			Run_motor_X(0,5);
			}
	}
	if(mpu6050_flag == 2)
	{
	LED2_OFF ();
	immobile_interface();
	refresh_interface();
	mpu6050_flag=0;
	}
}



void serial_control(void)
{
	if (Serial_RxFlag == 1)
			{	
				LED1_OFF ();
				uint8_t len;
				len=strlen(Serial_RxPacket);
				if(Serial_RxPacket[0]=='X' && Serial_RxPacket[len-1]=='M')
				{
					char robot_arm_RxPacket[300];		//接收到数据最多有多少个字符串
					memcpy(robot_arm_RxPacket,Serial_RxPacket+1,len-2); //把前面后面起始位停止位去掉
					robot_arm_RxPacket[len-2]='\0';
					//printf("第一次拆分%s",robot_arm_RxPacket);
					char *separate_package=strtok(robot_arm_RxPacket," ");  //把 前后的数据分开
					char* separate_arms_control[20];		//可以接收到多少组数据
					int i=0;
					while(separate_package)
					{
						separate_arms_control[i]=separate_package;
						i++;
						//printf("组拆分%s",separate_package);
						separate_package = strtok(NULL," ");
					}
					int control_number=0;
					printf("需要执行%d组数据",i);
					for( ; control_number<=i-1;)
					{
						printf("\r\n正在执行%d组数据\r\n",control_number+1);
						int len_=0;
						len_=strlen(separate_arms_control[control_number]);
					//control_number++;
						//printf("有%d个数据",len_);
						if (separate_arms_control[control_number][0]=='(' && separate_arms_control[control_number][len_-1]==')')
						{
							int size_ = sizeof(separate_arms_control[control_number])/sizeof(char*);	//获取拆分数据个数
							char single_arms_control[size_];
							memcpy(single_arms_control,separate_arms_control[control_number]+1,len_-2); //把前面后面俩括号去掉
							single_arms_control[len_-2]='\0';
							char *token=strtok(single_arms_control,",");  //把,前后的数据分开
							char *arms_control[5];
							int counter=0;
							while(token)
								{
									arms_control[counter]=token;
									counter++;
									printf("%s",token);
									token = strtok(NULL,",");
								}
							if(state==0)
								{
									x=atof(arms_control[0]);
									y=atof(arms_control[1]);
									z=atof(arms_control[2]);  //xyz数组来接赋值给逆运动学
									g=atof(arms_control[3]);
									if(counter>=5)		//判断有没有速度变量进来
									{
										speed=atof(arms_control[4]);
										TIM2_config(speed);	//重新初始一下，改变arr来改变速度
									}
									Inverse_angle(x,y,z);//逆向运动学给期望角度
									Radial_Move();		//角度给3电机运行
									Servo_control(g);	//舵机
								refresh_interface();	//屏幕刷新
								printf("(%d,%d,%d,%d,%d)\r\n",(int)x,(int)y,(int)z,(int)g,state);
								//if (mode ==1)
								//	{
									LCD_Show_pmgressbar(70,10,50,i-1,control_number,RED,orange);
									while(state==1);
								//	}
								}
						}
						control_number++;		//记数据次数
					}	
				}
				
				else if (strcmp(Serial_RxPacket, "Reset") == 0)
				{
				Motor_reset();
				}
				else if (strcmp(Serial_RxPacket, "Sync") == 0)
				{
				printf("(%d,%d,%d,%d,%d)\r\n",(int)x,(int)y,(int)z,(int)g,state);
				}
				else if (strcmp(Serial_RxPacket, "Disable") == 0)
				{
				GPIO_SetBits(GPIOA,Motor_ENABLE);
				}
				else if (strcmp(Serial_RxPacket, "Enable") == 0)
				{
				GPIO_ResetBits(GPIOA,Motor_ENABLE);
				}
				else if (strncmp(Serial_RxPacket, "Speed",5)==0)
				{
				char speed_[4];
				memcpy(speed_,Serial_RxPacket+5,len-5);
				speed=atoi(speed_);
				printf("%d",speed);
				TIM2_config(speed);
				}
				else if (strncmp(Serial_RxPacket, "Mode",4)==0)
				{
				char mode_[1];
				memcpy(mode_,Serial_RxPacket+4,1);
				mode=atoi(mode_);
				if(mode==1)mpu6050_flag=1;
					else mpu6050_flag =2;
				printf("%d",mode);
				}
				else if (strncmp(Serial_RxPacket, "Grip",4)==0)
				{
				char Grip[1];
				memcpy(Grip,Serial_RxPacket+4,1);
				uint8_t grip=atof(Grip);
				Servo_control(grip);	//舵机
				printf("夹爪%d\r\n",grip);
				}
				else if (strncmp(Serial_RxPacket, "Run",3)==0)
				{
					char motor[1];char Dir[1];
					memcpy(motor,Serial_RxPacket+3,1);
					memcpy(Dir,Serial_RxPacket+4,1);
					uint8_t dir=atoi(Dir);
					  switch(motor[0])
					   {
						case 'X' :Run_motor_X(dir,200);break;
						case 'Y' :Run_motor_Y(dir,200);break;
						case 'Z' :Run_motor_Z(dir,200);break;
					   }
					   printf("电机%s%d\r\n",motor,dir); 
				}
				else if (strncmp(Serial_RxPacket, "Stop",4)==0)
				{
					char motor[1];
					memcpy(motor,Serial_RxPacket+4,1);
					  switch(motor[0])
					   {
						case 'X' :Stop_motor_X ();break;
						case 'Y' :Stop_motor_Y ();break;
						case 'Z' :Stop_motor_Z ();break;
					   }
					   printf("电机%s停止\r\n",motor);
				}
				else
				{
				Serial_SendString("ERROR_COMMAND\r\n");
				}
			//printf("(%d,%d,%d,%d,%d)\r\n",(int)x,(int)y,(int)z,(int)g,state);
			Serial_RxFlag = 0;
			}
}

int main(void)
{	
	LCD_Init();	   //液晶屏初始化
	immobile_interface();
	refresh_interface();
	Serial_Init();	
	LED_Init ();
	TIM2_config(speed);	
	GPIO_Motor_Init();
	LIMIT_Init();
	Servo_Init();
	IIC_Init();
	while(1)
		{

		LED1_ON ();
		MPU6050_control (mode);
		serial_control();
		}
}
		

