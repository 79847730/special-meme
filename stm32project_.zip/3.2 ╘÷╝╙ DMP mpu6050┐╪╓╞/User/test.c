#include "lcd.h"
#include "delay.h"
#include "gui.h"
#include "test.h"
#include "picture.h"

#include "servo.h"
extern int reality_x_angle,reality_y_angle,reality_z_angle;	//ʵ�ʻ�е�۵ĽǶ� 
extern uint16_t  speed;
extern float  x,y,z;
//========================variable==========================//
u16 ColorTab[5]={RED,GREEN,BLUE,YELLOW,BRED};//������ɫ����
//=====================end of variable======================//

/*****************************************************************************
 * @name       :void DrawTestPage(u8 *str)
 * @date       :2018-08-09 
 * @function   :Drawing test interface
 * @parameters :str:the start address of the Chinese and English strings
 * @retvalue   :None
******************************************************************************/ 
void DrawTestPage(u8 *str)
{
//���ƹ̶���up
LCD_Clear(WHITE);
LCD_Fill(0,0,lcddev.width,20,BLUE);
//���ƹ̶���down
LCD_Fill(0,lcddev.height-20,lcddev.width,lcddev.height,BLUE);
POINT_COLOR=WHITE;
Gui_StrCenter(0,2,WHITE,BLUE,str,16,1);//������ʾ
Gui_StrCenter(0,lcddev.height-18,WHITE,BLUE,"www.lcdwiki.com",16,1);//������ʾ
//���Ʋ�������
//LCD_Fill(0,20,lcddev.width,lcddev.height-20,WHITE);
}

/*****************************************************************************
 * @name       :void Display_ButtonUp(u16 x1,u16 y1,u16 x2,u16 y2)
 * @date       :2018-08-24 
 * @function   :Drawing a 3D button
 * @parameters :x1:the bebinning x coordinate of the button
                y1:the bebinning y coordinate of the button
								x2:the ending x coordinate of the button
								y2:the ending y coordinate of the button
 * @retvalue   :None
******************************************************************************/ 
void Display_ButtonUp(u16 x1,u16 y1,u16 x2,u16 y2)
{
	POINT_COLOR=WHITE;
	LCD_DrawLine(x1,  y1,  x2,y1); //H
	LCD_DrawLine(x1,  y1,  x1,y2); //V
	
	POINT_COLOR=GRAY1;
	LCD_DrawLine(x1+1,y2-1,x2,y2-1);  //H
	POINT_COLOR=GRAY2;
	LCD_DrawLine(x1,y2,x2,y2);  //H
	POINT_COLOR=GRAY1;
	LCD_DrawLine(x2-1,y1+1,x2-1,y2);  //V
	POINT_COLOR=GRAY2;
  LCD_DrawLine(x2,y1,x2,y2); //V
}

/*****************************************************************************
 * @name       :void menu_test(void)
 * @date       :2018-08-24 
 * @function   :Drawing a 3D menu UI
 * @parameters :None
 * @retvalue   :None
******************************************************************************/ 
void menu_test(void)
{
	LCD_Clear(YELLOW);
	
	Display_ButtonUp(15,8,113,28); //x1,y1,x2,y2
	Gui_StrCenter(0,10,BRED,BLUE,"ͼ����ʾ����",16,1);

	Display_ButtonUp(15,38,113,58); //x1,y1,x2,y2
	Gui_StrCenter(0,40,BLACK,GRAY0,"��ɫ������",16,1);
	
	Display_ButtonUp(15,68,113,88); //x1,y1,x2,y2
	Gui_StrCenter(0,70,BLUE,GRAY0,"������ʾ����",16,1);

	Display_ButtonUp(15,98,113,118); //x1,y1,x2,y2
	Gui_StrCenter(16,100,RED,GRAY0,"ͼƬ��ʾ����",16,1);
	delay_ms(1500);
	delay_ms(500);
}

/*****************************************************************************
 * @name       :void main_test(void)
 * @date       :2018-08-09 
 * @function   :Drawing the main Interface of the Comprehensive Test Program
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void main_test(void)
{
	DrawTestPage("�ۺϲ��Գ���");	
	Gui_StrCenter(0,23,RED,BLUE,"ȫ������",16,1);//������ʾ
	Gui_StrCenter(0,40,RED,BLUE,"�ۺϲ��Գ���",16,1);//������ʾ	
	Gui_StrCenter(0,57,GREEN,BLUE,"1.44\" ST7735S",16,1);//������ʾ
	Gui_StrCenter(0,74,GREEN,BLUE,"128X128",16,1);//������ʾ
	Gui_StrCenter(0,91,BLUE,BLUE,"2018-08-24",16,1);//������ʾ
	delay_ms(1500);		
	delay_ms(1500);
}

/*****************************************************************************
 * @name       :void Test_Color(void)
 * @date       :2018-08-09 
 * @function   :Color fill test(white,black,red,green,blue)
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void Test_Color(void)
{
	//DrawTestPage("����1:��ɫ������");
	LCD_Fill(0,0,lcddev.width,lcddev.height,WHITE);
	Show_Str(20,30,BLUE,YELLOW,"BL Test",16,1);delay_ms(800);
	LCD_Fill(0,0,lcddev.width,lcddev.height,RED);
	Show_Str(20,30,BLUE,YELLOW,"RED ",16,1);delay_ms(800);
	LCD_Fill(0,0,lcddev.width,lcddev.height,GREEN);
	Show_Str(20,30,BLUE,YELLOW,"GREEN ",16,1);delay_ms(800);
	LCD_Fill(0,0,lcddev.width,lcddev.height,BLUE);
	Show_Str(20,30,RED,YELLOW,"BLUE ",16,1);delay_ms(800);
}

/*****************************************************************************
 * @name       :void Test_FillRec(void)
 * @date       :2018-08-09 
 * @function   :Rectangular display and fill test
								Display red,green,blue,yellow,pink rectangular boxes in turn,
								1500 milliseconds later,
								Fill the rectangle in red,green,blue,yellow and pink in turn
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void Test_FillRec(void)
{
	u8 i=0;
	DrawTestPage("GUI����������");
	LCD_Fill(0,20,lcddev.width,lcddev.height-20,WHITE);
	for (i=0; i<5; i++) 
	{
		POINT_COLOR=ColorTab[i];
		LCD_DrawRectangle(lcddev.width/2-40+(i*16),lcddev.height/2-40+(i*13),lcddev.width/2-40+(i*16)+30,lcddev.height/2-40+(i*13)+30); 
	}
	delay_ms(1500);	
	LCD_Fill(0,20,lcddev.width,lcddev.height-20,WHITE); 
	for (i=0; i<5; i++) 
	{
		POINT_COLOR=ColorTab[i];
		LCD_DrawFillRectangle(lcddev.width/2-40+(i*16),lcddev.height/2-40+(i*13),lcddev.width/2-40+(i*16)+30,lcddev.height/2-40+(i*13)+30); 
	}
	delay_ms(1500);
}

/*****************************************************************************
 * @name       :void Test_Circle(void)
 * @date       :2018-08-09 
 * @function   :circular display and fill test
								Display red,green,blue,yellow,pink circular boxes in turn,
								1500 milliseconds later,
								Fill the circular in red,green,blue,yellow and pink in turn
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void Test_Circle(void)
{
	u8 i=0;
	DrawTestPage("GUI��Բ������");
	LCD_Fill(0,20,lcddev.width,lcddev.height-20,WHITE);
	for (i=0; i<5; i++)  
		gui_circle(lcddev.width/2-40+(i*15),lcddev.height/2-25+(i*13),ColorTab[i],15,0);
	delay_ms(1500);	
	LCD_Fill(0,20,lcddev.width,lcddev.height-20,WHITE); 
	for (i=0; i<5; i++) 
	  	gui_circle(lcddev.width/2-40+(i*15),lcddev.height/2-25+(i*13),ColorTab[i],15,1);
	delay_ms(1500);
}

/*****************************************************************************
 * @name       :void English_Font_test(void)
 * @date       :2018-08-09 
 * @function   :English display test
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void English_Font_test(void)
{
	DrawTestPage("Ӣ����ʾ����");
	Show_Str(10,22,BLUE,YELLOW,"6X12:abcdefgh01234567",12,0);
	Show_Str(10,34,BLUE,YELLOW,"6X12:ABCDEFGH01234567",12,1);
	Show_Str(10,47,BLUE,YELLOW,"6X12:~!@#$%^&*()_+{}:",12,0);
	Show_Str(10,60,BLUE,YELLOW,"8X16:abcde01234",16,0);
	Show_Str(10,76,BLUE,YELLOW,"8X16:ABCDE01234",16,1);
	Show_Str(10,92,BLUE,YELLOW,"8X16:~!@#$%^&*()",16,0); 
	delay_ms(1200);
}

/*****************************************************************************
 * @name       :void Test_Triangle(void)
 * @date       :2018-08-09 
 * @function   :triangle display and fill test
								Display red,green,blue,yellow,pink triangle boxes in turn,
								1500 milliseconds later,
								Fill the triangle in red,green,blue,yellow and pink in turn
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void Test_Triangle(void)
{
	u8 i=0;
	DrawTestPage("GUI Tri������");
	LCD_Fill(0,20,lcddev.width,lcddev.height-20,WHITE);
	for(i=0;i<5;i++)
	{
		POINT_COLOR=ColorTab[i];
		Draw_Triangel(lcddev.width/2-40+(i*15),lcddev.height/2-12+(i*11),lcddev.width/2-25-1+(i*15),lcddev.height/2-12-26-1+(i*11),lcddev.width/2-10-1+(i*15),lcddev.height/2-12+(i*11));
	}
	delay_ms(1500);	
	LCD_Fill(0,20,lcddev.width,lcddev.height-20,WHITE); 
	for(i=0;i<5;i++)
	{
		POINT_COLOR=ColorTab[i];
		Fill_Triangel(lcddev.width/2-40+(i*15),lcddev.height/2-12+(i*11),lcddev.width/2-25-1+(i*15),lcddev.height/2-12-26-1+(i*11),lcddev.width/2-10-1+(i*15),lcddev.height/2-12+(i*11));
	}
	delay_ms(1500);
}

/*****************************************************************************
 * @name       :void Chinese_Font_test(void)
 * @date       :2018-08-09 
 * @function   :chinese display test
 * @parameters :None
 * @retvalue   :None
******************************************************************************/
void Chinese_Font_test(void)
{	
	DrawTestPage("������ʾ����");
	Show_Str(10,25,BLUE,WHITE,"16X16:��е��",16,1);
	Show_Str(10,45,BLUE,YELLOW,"24X24:���Ĳ���",24,0);
	Show_Str(10,70,BLUE,YELLOW,"32X32:�������",32,1);
	delay_ms(1200);
}


void immobile_interface(void)
{	
//	LCD_Clear(WHITE);
//	LCD_Fill(0,0,lcddev.width,20,GRED);
//	//���ƹ̶���down
//	LCD_Fill(0,lcddev.height-20,lcddev.width,lcddev.height,GRED);
//	POINT_COLOR=GRED;
	LCD_Clear(BLACK);
	LCD_Fill(0,0,lcddev.width,20,orange);
	LCD_ShowPicture(73,48,55,80,gImage_01);	
	POINT_COLOR = RED;
	LCD_Show_Progress_bar_box(70,10,50);
	LCD_Show_Progress_bar_box(90,40,35);
	Show_Str(88,20,RED,WHITE,"��λ",16,1);
	//Gui_StrCenter(0,2,RED,WHITE,"��е�������",16,1);//������ʾ
	Show_Str(6,2,RED,WHITE,"AsuKa",16,1);
	Show_Str(0,20,RED,WHITE,"�� ��:",16,1);
	Show_Str(0,35,RED,WHITE,"X�Ƕ�:",16,1);
	Show_Str(0,50,RED,WHITE,"Y�Ƕ�:",16,1);
	Show_Str(0,65,RED,WHITE,"Z�Ƕ�:",16,1);
	Show_Str(0,80,RED,WHITE,"����x y z",16,1);
	Show_Str(0,96,RED,WHITE,"(         )",16,1);
	Show_Str(0,112,RED,WHITE,"�� צ:",16,1);
	
}

void refresh_interface(void)
{
		BACK_COLOR=BLACK;
		POINT_COLOR = RED,
		LCD_ShowNum(50,21,speed,3,16);	
		LCD_ShowNum(50,35,reality_x_angle,3,16);	
		LCD_ShowNum(50,50,reality_y_angle,3,16);	
		LCD_ShowNum(50,65,reality_z_angle,3,16);
		POINT_COLOR = MAGENTA,
		LCD_ShowNum(7,96,x,3,16);
		POINT_COLOR = GREEN,
		LCD_ShowNum(33,96,y,3,16);
		POINT_COLOR = BLUE,
		LCD_ShowNum(58,96,z,3,16);
		if( state_Servo()==1)
			{
		Show_Str(60,112,RED,BLACK,"��",16,0);
			}
		if(state_Servo()==0)
			{
		Show_Str(60,112,RED,BLACK,"��",16,0);
			}
}

void interface_6050 (void)
{
	LCD_Clear(WHITE);
	Show_Str(10,50,RED,WHITE,"MPU6050��ʼ����",16,1);
}
	
void immobile_interface_6050(void)
{
	LCD_Clear(WHITE);
	Show_Str(10,35,RED,WHITE,"Pitch:",16,1);
	Show_Str(10,50,RED,WHITE,"Roll :",16,1);
	Show_Str(10,65,RED,WHITE,"Yaw  :",16,1);
}

void refresh_interface_6050 ( float  Pitch,float Roll,float Yaw)
{
	BACK_COLOR=WHITE;
	POINT_COLOR = 0x001F;
	LCD_ShowNum(70,35,Pitch,3,16);	
	LCD_ShowNum(70,50,Roll,3,16);	
	LCD_ShowNum(70,65,Yaw,3,16);
	if(Pitch<0)
	{
	POINT_COLOR = 0x001F;
	LCD_DrawLine(60,42,65,42);
	}
	else 
	{
	POINT_COLOR = 0xFFFF;
	LCD_DrawLine(60,42,65,42);
	}
	if(Roll<0)
	{
	POINT_COLOR = 0x001F;
	LCD_DrawLine(60,57,65,57);
	}
	else 
	{
	POINT_COLOR = 0xFFFF;
	LCD_DrawLine(60,57,65,57);
	}
	if(Yaw<0)
	{
	POINT_COLOR = 0x001F;
	LCD_DrawLine(60,72,65,72);
	}
	else 
	{
	POINT_COLOR = 0xFFFF;
	LCD_DrawLine(60,72,65,72);
	}

}

